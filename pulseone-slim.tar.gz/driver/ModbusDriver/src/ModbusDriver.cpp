#include <iostream>

extern "C" void hello() {
    std::cout << "ModbusDriver 플러그인 테스트!" << std::endl;
}
