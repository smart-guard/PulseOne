# backend

Node.js 기반 백엔드 및 DB저장 서비스 소스코드를 관리합니다.

- REST/gRPC API, DB저장, 사용자/설정 관리, 알람/이력 처리 등 담당
- Express, NestJS, Fastify 등 프레임워크 사용 가능
- 환경설정, 의존성, 실행 방법 등은 본 폴더에서 안내합니다.
